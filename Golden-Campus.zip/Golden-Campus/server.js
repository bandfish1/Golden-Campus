
const express = require('express');
const http = require('http');
const app = express();
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);

// Serve static files
app.use(express.static('./'));

// Store chat messages
let messages = [];
const connectedUsers = {};

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  // Handle user joining
  socket.on('join', (username) => {
    connectedUsers[socket.id] = username;
    io.emit('user-joined', username);
    io.emit('user-list', Object.values(connectedUsers));
    
    // Send past messages to new user
    socket.emit('message-history', messages);
  });
  
  // Handle chat messages
  socket.on('chat-message', (message) => {
    const messageData = {
      username: connectedUsers[socket.id] || 'Anonymous',
      message: message,
      timestamp: Date.now()
    };
    
    messages.push(messageData);
    if (messages.length > 100) messages.shift(); // Keep only latest 100 messages
    
    io.emit('chat-message', messageData);
  });
  
  // Handle disconnection
  socket.on('disconnect', () => {
    if (connectedUsers[socket.id]) {
      io.emit('user-left', connectedUsers[socket.id]);
      delete connectedUsers[socket.id];
      io.emit('user-list', Object.values(connectedUsers));
    }
  });
});

// Use only port 5000, with no fallback ports
const PORT = 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Chat server running on port ${PORT}`);
}).on('error', (err) => {
  console.error(`Server error: ${err.message}`);
  process.exit(1); // Exit on error instead of trying other ports
});
