
// Disclaimer Modal Script
document.addEventListener('DOMContentLoaded', function() {
  const disclaimerModal = document.getElementById('disclaimerModal');
  const agreeButton = document.getElementById('agreeButton');
  
  // Check if user has already agreed
  if (!localStorage.getItem('disclaimerAgreed')) {
    disclaimerModal.style.display = 'flex';
  } else {
    disclaimerModal.style.display = 'none';
  }
  
  // Handle agree button click
  agreeButton.addEventListener('click', function() {
    localStorage.setItem('disclaimerAgreed', 'true');
    disclaimerModal.style.display = 'none';
  });
});

// GoGuardian Detection Script
(function() {
  // List of events that might indicate monitoring
  const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'touchmove'];
  
  // Variables to track behavior
  let lastActivity = Date.now();
  let monitoringDetected = false;
  let checkInterval = null;
  
  // Function to detect unusual behavior
  function detectMonitoring() {
    // If no user activity for 10 seconds but mouse is moving slightly or screen properties are being read
    // this could indicate remote monitoring
    const timeSinceActivity = Date.now() - lastActivity;
    
    if (timeSinceActivity > 30000) {
      // Check if DevTools is open (can be a sign of inspection)
      if (window.outerHeight - window.innerHeight > 200 || window.outerWidth - window.innerWidth > 200) {
        closeTab();
        return;
      }
      
      // Check if a canvas or document element is being captured
      try {
        const testCanvas = document.createElement('canvas');
        const context = testCanvas.getContext('2d');
        context.fillText('GoGuardian Detection', 0, 0);
        const imageData = context.getImageData(0, 0, 10, 10);
        
        // If the test canvas was accessed in an unusual way, it might be monitored
        if (imageData && Math.random() < 0.1) { // Randomly check to avoid false positives
          closeTab();
        }
      } catch (e) {
        // Permission errors can indicate monitoring
        closeTab();
      }
    }
  }
  
  // Update last activity time when user interacts
  function updateActivity() {
    lastActivity = Date.now();
  }
  
  // Function to close the tab
  function closeTab() {
    if (!monitoringDetected) {
      monitoringDetected = true;
      window.close();
      
      // Fallback if window.close() is blocked
      document.body.innerHTML = '';
      window.location.href = 'about:blank';
    }
  }
  
  // Add event listeners for user activity
  events.forEach(event => {
    window.addEventListener(event, updateActivity, true);
  });
  
  // Set up periodic checks
  checkInterval = setInterval(detectMonitoring, 2000);
  
  // Additional detection for visibility changes
  document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'hidden') {
      // The tab became hidden - could be due to monitoring software
      setTimeout(() => {
        if (Math.random() < 0.3) { // Random chance to avoid false positives
          closeTab();
        }
      }, 500);
    }
  });
})();
